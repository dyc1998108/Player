from propnet import propnet
import sys

fn = sys.argv[1]

propnet.convert_to_propnet(fn)
