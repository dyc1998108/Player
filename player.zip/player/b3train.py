import pyximport
pyximport.install()
from b3 import B3Node, do_game
from propnet.propnet import load_propnet
from model import Model
from utils.pauser import set_pauser
import time
import sys
import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

game = sys.argv[1]

def average(scores, q, z):
    return {role: z*sc + (1-z)*q[role]
            for role, sc in scores.items()}

data, propnet = load_propnet(game)
model = Model(propnet)
model.load_most_recent(game)
model.save(game, 13000)
cur = [None]

set_pauser({
    'cur': cur,
    'model': model,
    'propnet': propnet,
})

start = time.time()
history = {}
memory = []
for i in range(13001, 14001):
    cur[0] = B3Node(propnet, data, model=model)
    print('Game number', i)
    states, scores = do_game(cur, propnet, model, z=0.5)
    for state in states:
        # print(type(state[0]))
        # state[0] = tuple(state[0])
        if state[0] not in history:
            history[state[0]] = len(memory)
            memory.append([state, 0, scores])
            print("New state")
        else:
            if history[state[0]] == -1: continue
            seq = history[state[0]]
            dev_probs = []
            dev_qs = 0
            flag = False
            for role in propnet.roles:
                d = (state[2][role] - memory[seq][0][2][role]) ** 2
                dev_qs += d
            dev_qs /= len(propnet.roles)
            if dev_qs <= 0.000004 and memory[seq][1] >= 100:
                for role in propnet.roles:
                    dev = 0
                    for j, prob in enumerate(state[1][role]):
                        d = (memory[seq][0][1][role][j] - state[1][role][j]) ** 2
                        dev += d
                    dev /= len(state[1][role])
                    dev_probs.append(dev)
                    if dev >= 0.000004:
                        flag = True
                        break
            else:
                flag = True

            if not flag:
                print("State Already")
                model.add_sample(memory[seq][0][0], memory[seq][0][1], average(scores, memory[seq][0][2], 1))
                memory.pop(seq)
                history[state[0]] = -1
            else:
                print("State Update")
                times = memory[seq][1]
                memory[seq][1] += 1
                for role in propnet.roles:
                    memory[seq][2][role] = (times * memory[seq][2][role] + scores[role]) / (times + 1)
                    memory[seq][0][2][role] = (times * state[2][role] + memory[seq][0][2][role]) / (times + 1)
                    for j, prob in enumerate(state[1][role]):
                        memory[seq][0][1][role][j] = (times * memory[seq][0][1][role][j] + state[1][role][j]) / (times + 1)

    # print("i = ", i)
    # print("i and i % 10 == 0 ? ", i and i % 10 == 0)
    if i and i % 1000 == 0:
        # print("Clearing memory")
        for sample in memory:
            model.add_sample(sample[0][0], sample[0][1], average(sample[2], sample[0][2], 1))
            # print("Adding sample : ", sample[0][0], sample[0][1], average(sample[2], sample[0][2], 1))
        history.clear()
        memory.clear()
        model.train(epochs=10)
        model.save(game, i)
        with open(f'models/times-{game}', 'a') as f:
            f.write(f'{i} {time.time()-start}\n')
end = time.time()
print(end - start)