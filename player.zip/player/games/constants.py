AND = 1
OR = 2
PROPOSITION = 3
TRANSITION = 4
NOT = 5
CONSTANT = 6
UNKNOWN = 7

MAX_FAN_OUT_SIZE = 256 * 256

init = "init"
base = "base"
input = "input"
legal = "legal"
goal = "goal"
terminal = "terminal"
other = "other"
