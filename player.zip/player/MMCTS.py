from mcts import MCTSNode


class MMCTSNode(MCTSNode):

    def __init__(self, propnet, data, actions=None, sum_start=0):
        super().__init__(propnet, data, actions, sum_start)

    def update(self, ids, scores):
        self.count += 1
        for role, id in zip(self.propnet.roles, ids):
            # print(self.q[role], self.move_counts[role][id], self.win_sums[role][id], scores[role])
            self.q[role] += 0.4 * scores[role]
            self.move_counts[role][id] += 1
            self.win_sums[role][id] += 0.4 * scores[role]

    def get_or_make_child(self, ids):
        # print(self.__class__)
        if ids not in self.children:
            self.children[ids] = self.__class__(self.propnet, self.data, set(ids), *self.children_args)
        return self.children[ids]

    def get_child(self):
        # print(self.__class__)
        actions = self.choose_actions()
        ids = tuple(actions[role].id for role in self.propnet.roles)
        if ids in self.children:
            return False, ids, self.children[ids]
        self.children[ids] = self.__class__(self.propnet, self.data, set(ids), *self.children_args)
        scores = self.children[ids].get_pred_scores()
        return True, ids, scores


