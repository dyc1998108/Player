import pyximport
pyximport.install()
from b2 import B2Node, do_game
from propnet.propnet import load_propnet
from model import Model
from utils.pauser import set_pauser
import time
import sys
import os
os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

game = sys.argv[1]

data, propnet = load_propnet(game)
model = Model(propnet)
model.load_most_recent(game)
model.save(game, 12500)
cur = [None]

set_pauser({
    'cur': cur,
    'model': model,
    'propnet': propnet,
})

start = time.time()
for i in range(12501, 13001):
    cur[0] = B2Node(propnet, data, model=model)
    print('Game number', i)
    do_game(cur, propnet, model, z=0.5)
    model.train(epochs=10)
    if i and i % 50 == 0:
        model.save(game, i)
        with open(f'models/times-{game}', 'a') as f:
            f.write(f'{i} {time.time()-start}\n')
end = time.time()
print(end - start)
